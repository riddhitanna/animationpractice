let words = window.quote.innerText.split(" "),
  newHTML = ``;
words.forEach((word) => {
  newHTML += `<span>${word}</span> `;
});
window.quote.innerHTML = newHTML;

